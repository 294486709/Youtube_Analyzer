from django.apps import AppConfig


class WebFinallyAppConfig(AppConfig):
    name = 'web_finally_app'
