from django.shortcuts import render
import predict
import Youtube_url


# Create your views here.
list=[]
def index(request):
    '''search='nba'
    #list =[search, 'other corresponding tags']
    if request.method == "POST":
        search=request.POST.get("search:",None)

        api = YTapi.youtube_search(search)
        video = api[0]
        videoid = api[1]'''



    #return 0
    return render(request,"index.html",{"data":list})

def index2(request):

    if request.method == "POST":
        search=request.POST.get("search:",None)

        class1 = predict.main(search)
        #list =[search, 'other corresponding tags']

        video0=Youtube_url.youtube_url(search)[0]
        videoid0 = video0
        video0 = 'https://www.youtube.com/watch?v='+video0
        video_video0= 'https://www.youtube.com/embed/'+videoid0

        video1 = Youtube_url.youtube_url(search)[2]
        videoid1 = video1
        video1 = 'https://www.youtube.com/watch?v=' + video1
        video_video1 = 'https://www.youtube.com/embed/' + videoid1

        video2 = Youtube_url.youtube_url(search)[4]
        videoid2 = video2
        video2 = 'https://www.youtube.com/watch?v=' + video2
        video_video2 = 'https://www.youtube.com/embed/' + videoid2

        video3 = Youtube_url.youtube_url(search)[6]
        videoid3 = video3
        video3 = 'https://www.youtube.com/watch?v=' + video3
        video_video3 = 'https://www.youtube.com/embed/' + videoid3



        if class1 == 'Film&Comedy':
            source1 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/film_comedy1.jpg?raw=true";
            tag = ["pixar movies","sci fi","thriller movies","Disney","the big bang theory","batman forever"]

        elif class1 =='Music':
            source1 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/music1.jpg?raw=true";
            tag = ["Ariana Grande","music video","billboard channel","Nicky Minaj","no tears left to cry"]

        elif class1 =='Entertainment':
            source1 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/entertaiment1.jpg?raw=true";
            tag = ["Valentine","Donald Glover","Samsung Galaxy","dancing on ice","ready player one"]

        elif class1 =='Howto&Style':
            source1 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/style1.jpg?raw=true";
            tag = ["pony makeup","how to make vanilla cupcakes","sprinkle of glitter","30 days of yoga","makeup tutorial"]

        elif class1 == 'Science&Education':
            source1 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/science_edu1.jpg?raw=true";
            tag = ["apple homepod review","ADAS","GMAT","Digital Culture","jet engine test"]

        elif class1 == 'Sports&Gaming':
            source1 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/sports_gaming1.jpg?raw=true";
            tag = ["National Hockey League","2018 NFL draft","pelicans vs warriors","Fifa world cup","BBC sports"]

        if class1 == 'Film&Comedy':
            source2 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/Film_comedy2.jpg?raw=true";

        elif class1 == 'Music':
            source2 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/music2.jpg?raw=true";

        elif class1 == 'Entertainment':
            source2 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/entertaiment2.jpg?raw=true";

        elif class1 == 'Howto&Style':
            source2 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/style2.jpg?raw=true";

        elif class1 == 'Science&Education':
            source2 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/science_edu2.jpg?raw=true";

        elif class1 == 'Sports&Gaming':
            source2 = "https://github.com/294486709/Youtube_Analyzer/blob/master/ads/sports_gaming2.jpg?raw=true?raw=true";





    return render(request, "index2.html",{"data":list,"class":class1,
                                          "source1":source1,"source2":source2,
                                          "tag":tag,"video0":video0,"video_video0":video_video0,"videoid0":videoid0,
                                          "video1":video1,"video_video1":video_video1,"videoid1":videoid1,
                                          "video2": video2, "video_video2": video_video2, "videoid2": videoid2,
                                          "video3": video3, "video_video3": video_video3, "videoid3": videoid3})#"videoid":videoid})




